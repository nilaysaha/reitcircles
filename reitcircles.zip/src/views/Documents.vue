<template>
  <div class="about">
    <v-container>
       <div>
         <h2 class="tw-text-center">Document upload center</h2>
       </div>
    </v-container>
  </div>
</template>
