<template>
  <v-app-bar elevation="0" app  >
    <v-container>
      <v-img alt=" Logo" contain src="@/assets/logo.png" transition="scale-transition" width="40" />
    </v-container>
  </v-app-bar>
</template>